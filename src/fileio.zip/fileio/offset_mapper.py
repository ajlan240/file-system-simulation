def logical_to_block_offset(offset, block_size):
    return offset // block_size
